  //get canvas
  var context = document.getElementById("main").getContext("2d");
  //set your brush(width and color)
  context.lineWidth= 10;
  context.strokeStyle =  "#0000FF";

  //set up your main canvas variables
  var mainCanvas = document.getElementById("main");
  //detect if its a click or the end of a drag
  var isClick = 0;
  var startDrawing = false;

  //detecting mouse events
  mainCanvas.addEventListener("mousedown",function(event){
   //detect a click
   isClick = 0;
   startDrawing= true;
   
  });
   mainCanvas.addEventListener("mouseup",function(event){
     startDrawing = false;
    //detect the difference between click and end of a drag
    if(isClick == 0){
      //insert code to draw rectangle
        var x = event.pageX - mainCanvas.offsetLeft;
        var y = event.pageY - mainCanvas.offsetTop;
      context.fillRect(x,y,context.lineWidth,context.lineWidth)
      console.log("person is clicking")
    }else if(isClick == 1){
       console.log("person is draging")
       context.beginPath();
    }
  });
   mainCanvas.addEventListener("mousemove",function(event){
     isClick = 1;
   //detect your mouse's(x,y)
   if(startDrawing == true){
   var x =  event.pageX - mainCanvas.offsetLeft;
        var y = event.pageY - mainCanvas.offsetTop;
   console.log(x+","+y);
   context.lineTo(x,y);
   context.closePath();
   context.stroke();
   context.moveTo(x,y);
   }
  });
   mainCanvas.addEventListener("mouseleave",function(event){
    startDrawing = false;
  });
  //new button
  document.getElementById("newDrawing").addEventListener("click",function(){
    context.clearRect(0,0,mainCanvas.width,mainCanvas.height);

  });
  //erase button
  document.getElementById("erase").addEventListener("click",function(){
   context.strokeStyle = "#ffffff";

  });
  //pink button
  document.getElementById("pink").addEventListener("click",function(){
   context.strokeStyle = "#ff0059";
   context.fillStyle = "#ff0059";

  });
  //pink button
  document.getElementById("yellow").addEventListener("click",function(){
   context.strokeStyle = "#edd97c";
   context.fillStyle = "#edd97c";

  });
  //blue button
  document.getElementById("blue").addEventListener("click",function(){
   context.strokeStyle = "#044aea";
   context.fillStyle = "#044aea";

  });
  //change the brush size
   document.getElementById("slider").addEventListener("change",function(){
     //logic
     var slidervalue = this.value;
     console.log(slidervalue);
     //user interface
     context.lineWidth = slidervalue;
   })
