//OUTPUT TO SCREEN
console.log("sdlsdlsd");
console.log(4+5);
/*variables */
var x = 45;
var y = 23.33;
var m = "hello";
var n = true;
console.log(y);
//array
var a = [3,4,4];
console.log(a[0]);
//dictionary
var c ={"name":"kamal","gpa":3.6}
//dictionary output
console.log(c.name);
//or
console.log(c["gpa"]);
var k = {"name":"kamal","courses":["MADT 3144","MADT 3245"]}
console.log(k.courses);
console.log(k.courses[0]);
var l = {"name":"kamal","friends":{"name": "prabh","pet":"dog" }}
//output dog to the SCREEN
var x = l["friends"];
var y = x["pet"];
console.log(y);
console.log(l.friends.pet);
var d = {
  "name":"pritesh",
  "id" : "C093491",
  "friend": {
    "name": "marcos",
    "pets": ["dog", "cat"],
    "grades" : {
      "4114":"A+",
      "4124":"C-"
    }
  },
  "food": {
    "pizza": {
      "1":"tomatos",
      "2":"chicken",
      "3":"salad"
    },
    "brunch":[83, 23, 14, 55]
  }
}
console.log(d.food.brunch[2]);
console.log(d.friend.pets[1]);
console.log(d.friend.grades["4124"]);
console.log(d.food.pizza["3"]);
var c = d.friend.grades["4124"];
var a = d.friend.grades["4114"];

a = 90/100;
c= 65/100;
console.log((90+65)/2);
var g={
  "A+":90,
  "C-":65
}
console.log((g[d.friend.grades["4124"]]+g[d.friend.grades["4114"]])/2)
//if statement in javascript
var x= 25;
if(x<10){
  console.log("HELLO");
}else{
  console.log("goodbye");
}
var a = ["apple","orange","banana"];
a.forEach(function(x){
  console.log(x);
});

//functions
function hello(){
  console.log("hello");
}
function bye(){
  console.log("bye");
}
//parameterize function
function add(a,b){
  console.log(a+b);
}
//return
function abc(){
  return "hello";
}
//use the function
hello();
add(12,20);
var z = abc();
console.log(z);
x=["a","b","b","a"];
var c = false;
function palindrome(x){
  for(var i = x.length;i>=0;i--){
 if(x[(x.length)-i]==x[i-1]){
   c=true;
   continue;
   
   
 }else{
  c= false;
  console.log("no");
  break;
 }
}
}
palindrome(x);
